PATH=$PATH:/www/wdlinux/mysql/bin
